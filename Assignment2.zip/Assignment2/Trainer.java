package Assignment2;

public class Trainer {

	
	public static void main(String[] args) {


		Trainer T1 = new Trainer("Mukesh" ,"Testing","mukesh@gmail.com", 1);
		Trainer T2 = new Trainer("Hitesh" ,"Dev","mukesh@gmail.com", 2);
		Trainer T3 = new Trainer("Sukesh" ,"DevOps","mukesh@gmail.com", 3);

	}
	
	 Trainer(String name,String department, String email, int id)
	 {
		 //System.out.println(name +" "+ department +" "+ email +" "+ id);
		 System.out.println(name +" "+"can teach" +" "+ department);

	 }

}

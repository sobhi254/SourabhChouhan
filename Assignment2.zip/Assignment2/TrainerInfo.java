package Assignment2;

public class TrainerInfo {

	
	public static void main(String[] args) {


		TrainerInfo T1 = new TrainerInfo("Mukesh" ,"Testing","mukesh@gmail.com", 1);
		TrainerInfo T2 = new TrainerInfo("Hitesh" ,"Dev","mukesh@gmail.com", 2);
		TrainerInfo T3 = new TrainerInfo("Sukesh" ,"DevOps","mukesh@gmail.com", 3);
	}
	
	 TrainerInfo(String name,String department, String email, int id)
	 {

		 Object []Tarray=new Object[4]  ;	
		 Tarray[0]=name;
		 Tarray[1]=department;
		 Tarray[2]=email;
		 Tarray[3]=id;

		 for (int i=0;i<Tarray.length;i++) 
		 {
			 System.out.println(Tarray[i]);
	     }

      }
}
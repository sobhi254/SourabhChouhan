package Assignment2;
import java.util.Scanner;

public class Studentsinfo {
	static Object [][]studentarray=new Object[5][5] ;
	static Scanner sc = new Scanner (System.in);
	
	
	
	public static void main(String[] args) {	
		
		System.out.println("Enter total no. of student");
		int stdCount =sc.nextInt();
		//Object [][]studentarray=new Object[stdCount][5] ;
		
for (int i=0;i<stdCount;i++) {
	Studentsinfo S1 = new Studentsinfo(i);		
				
			}	
		
		System.out.println("Please enter which student details are you looking for");
		int result=sc.nextInt();
	
for (int i=1;i<=studentarray[0].length;i++) {
			
			System.out.println(studentarray[result][i]);
				
			}
	}
	Studentsinfo(int stdNumber)
	{
		System.out.println("Enter the name");
		String stdName=sc.next();
		System.out.println("Enter the email");
		String stdEmail=sc.next();
		System.out.println("Enter the phone");
		String stdPhone=sc.next();
		System.out.println("Enter the address");
		String stdAdrs=sc.next();
		System.out.println("Enter the status");
		String stdStatus=sc.next();
			
				studentarray[stdNumber][0]=stdName;
				studentarray[stdNumber][1]=stdEmail;
				studentarray[stdNumber][2]=stdPhone;
				studentarray[stdNumber][3]=stdAdrs;
				studentarray[stdNumber][4]=stdStatus;
				
   }
	
}

